## Overview section
This pack can be used to restore the artifacts in another environment.

## Pre-Requisite Steps
- 'AI Projects Administration App' pack should be in Activated State before proceeding with the activation of this pack.

## Quick Start Guide
1. If there are steps listed in Pre-requisite section, complete them.
2. Upload the pack and activate it.
3. Restart the portal-backend container for toolsets to get registered.
4. After restart, you can see a project with name 'Base' been created with some basic AI artifacts.
