This pack is designed for metric collection for VROPs using the following bots:  
   
- **vm-summary**  
- **metric-list**  
- **metrics**


### Quick Start Guide  
   
| Step | Description                                                                                                                                                                                                                       |  
|------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|  
| 1    | Activate the solution pack. After the Pack is in `ACTIVATED` status, use `Enable Single Tenant` menu option to enable the pack.                                                                                                   |  
| 2    | Use `Launch Dashboard` menu option to navigate to the pack's dashboard. Note: For multinent tenant environment, the pack specific dashboards will be available in Customer Ops page.                                              |     
| 3   | Use `Configure and Manage` ->  `Vrops Credentials` to create credentials of type `vrops`  with the correct values.                                                                                                                |   
| 4    | Use `Configure and Manage` -> `Vrops Discovery Targets` to on board all the credentials specified for Vrops.                                                                                                                      |  
| 5    | Under `Configure and Manage` ->  `Run Discovery`  use `Run Access Verification` option to perform the credential check for Vrops. The verification results can be seen in `Access Verification Status` dashboard page.            |  
| 6    | Use `Configure and Manage` ->  `Run Discovery` to view and/or edit the schedule of the discovery or run the discovery on demand using `Run Vrops Metric Collection Rule` and after that run `Run Vrops Metric Collection` option. |  
| 7    | After the collection completes successfully, use the pages under `Vrops Metrics` to view the Metric data.                                                                                                                         |